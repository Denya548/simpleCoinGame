#pragma once 
#include "Program.hpp"

struct Coin{
	SDL_Rect destR = {0, 0, 64, 64};
	SDL_Texture *texture;
	int money = 10;
	int maxMoney = 10;
	bool isRandom = true; //position

	char bar[13] = "[----------]";

	void render(SDL_Renderer* rend, SDL_Texture* tex, SDL_Rect* destR);
	bool clickCheck(int mousePos[2]);
	void update(Coin c[]);

	int tempDelay = 0;
	int delay = 2000;
	bool cd = true;
};
