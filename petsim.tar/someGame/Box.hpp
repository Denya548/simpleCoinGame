#pragma once 
#include "Program.hpp"

struct Box{
	SDL_Rect destR = {540 - 50, 0, 50, 120}; //first 540 
	int cost = 548;	
	int ID = 5; //all pets	
	int delay = 256 * 4;	
	int strength = 1;	
};
